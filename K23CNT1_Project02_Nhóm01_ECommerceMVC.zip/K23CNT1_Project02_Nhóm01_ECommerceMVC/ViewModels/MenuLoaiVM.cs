﻿namespace ECommerceMVC.ViewModels
{
    public class MenuLoaiVM
    {
        public int MaLoai { get; set; }
        public string TenLoai { get; set; }
        public int SoLuong { get; set; }
    }
}