﻿namespace ECommerceMVC.ViewModels
{
    public class CartModel
    {
        public int Quantity { get; set; }
        public double Total { get; set; }
    }
}